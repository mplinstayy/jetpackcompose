package com.bignerdranch.android.jetpackcompose.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val Red = Color(0xFFEE6055)
val Green = Color(0xFF60D394)
val LimeGreen = Color(0xFFAAF683)
val Yellow = Color(0xFFFFD97D)
val Salmon = Color(0xFFFF9B85)
val White = Color(0xFFFFFFFF)
val Gray = Color(0xFFEBEBEB)